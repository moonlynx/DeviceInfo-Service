module.exports = function(funcName, error) {
    return funcName + " -> " + error.toString();
}